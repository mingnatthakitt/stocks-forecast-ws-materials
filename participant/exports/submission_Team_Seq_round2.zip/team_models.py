import torch
import torch.nn as nn
SEED = 42


class LSTMRegressor(nn.Module):
    def __init__(self, n_features: int, hidden_size: int = 32, num_layers: int = 1,
                 dropout: float = 0.2):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden_size, num_layers,
                            batch_first=True, dropout=dropout if num_layers > 1 else 0.0)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden_size, 1))

    def forward(self, x):                      # x: (batch, seq_len, n_features)
        out, _ = self.lstm(x)
        return self.head(out[:, -1, :])        # state after the most recent day


class GRURegressor(nn.Module):
    def __init__(self, n_features: int, hidden_size: int = 32, num_layers: int = 1,
                 dropout: float = 0.2):
        super().__init__()
        self.gru = nn.GRU(n_features, hidden_size, num_layers,
                          batch_first=True, dropout=dropout if num_layers > 1 else 0.0)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden_size, 1))

    def forward(self, x):
        out, _ = self.gru(x)
        return self.head(out[:, -1, :])


class CNN1DRegressor(nn.Module):
    """Reads the window with local conv filters — pattern-spotter, not memoriser."""
    def __init__(self, n_features: int, channels: int = 32, kernel_size: int = 5,
                 dropout: float = 0.2):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(n_features, channels, kernel_size, padding=kernel_size // 2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(channels, 1))

    def forward(self, x):                      # (batch, seq_len, n_features)
        z = self.conv(x.permute(0, 2, 1))      # -> (batch, channels, 1)
        return self.head(z.flatten(1))


def build_torch_model(arch: str, params: dict, n_features: int) -> nn.Module:
    torch.manual_seed(SEED)
    if arch == "lstm":
        return LSTMRegressor(n_features, params.get("hidden_size", 32),
                             params.get("num_layers", 1), params.get("dropout", 0.2))
    if arch == "gru":
        return GRURegressor(n_features, params.get("hidden_size", 32),
                            params.get("num_layers", 1), params.get("dropout", 0.2))
    if arch == "cnn":
        return CNN1DRegressor(n_features, params.get("channels", 32),
                              params.get("kernel_size", 5), params.get("dropout", 0.2))
    raise ValueError(f"unknown sequence architecture: {arch}")
